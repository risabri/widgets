import React, { useState, useEffect } from "react";
import DataTest from "../src/DataTest";

export default { title: "DataTest" };

export const app = () => {
  return <DataTest data={{}} />;
};
app.story = {
  name: "DataTest",
};
