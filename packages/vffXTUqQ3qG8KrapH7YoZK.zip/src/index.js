/**
 * Entrypoint of the Remote Component.
 */
//import { App } from "./App";

//export default App;
import DataTest from "./DataTest";
export default DataTest;
