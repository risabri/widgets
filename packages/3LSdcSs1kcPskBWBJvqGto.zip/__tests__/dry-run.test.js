'use strict';

const dryRun = require('..');

describe('dry-run', () => {
    it('needs tests');
});
