export const days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
export const dayLetter = ["Sun", "Mon", "Thu", "Wed", "Thu", "Fri", "Sat"];
//export const dayLetter = ["U", "M", "T", "W", "R", "F", "S"];
//export const dayLetter = ["S", "M", "T", "W", "T", "F", "S"];
export const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
