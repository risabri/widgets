/**
 * Entrypoint of the Remote Component.
 */
//import { App } from "./App";

//export default App;
import DryRun from "./DryRun";
export default DryRun;
