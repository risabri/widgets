// export const API_KEY = "927616b3850fcec94b33c35a6b270c1d";
export const API_KEY = "e72f4e2b049a4ca7918223846212007";

export const API_BASE_URL = "http://api.weatherapi.com";
