# `dry-run`

> TODO: description

## Usage

```
const dryRun = require('dry-run');

// TODO: DEMONSTRATE API
```
