'use strict';

const weather = require('..');

describe('weather', () => {
    it('needs tests');
});
