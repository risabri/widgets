// https://home.openweathermap.org/api_keys
// export const API_KEY = "30cdb46eca30d8b1f5590744995b4c69";
// export const API_BASE_URL = "http://api.openweathermap.org";

export const API_KEY = "e72f4e2b049a4ca7918223846212007";

export const API_BASE_URL = "http://api.weatherapi.com";
