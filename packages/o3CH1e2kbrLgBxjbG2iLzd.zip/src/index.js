/**
 * Entrypoint of the Remote Component.
 */
import App from "./App";

export default App;
