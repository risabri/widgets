# `weather`

> TODO: description

## Usage

```
const weather = require('weather');

// TODO: DEMONSTRATE API
```
