/**
 * Entrypoint of the Remote Component.
 */
//import { App } from "./App";

//export default App;
import HolisticHealth from "./HolisticHealth";
export default HolisticHealth;
