'use strict';

const holisticHealth = require('..');

describe('holistic-health', () => {
    it('needs tests');
});
